<?= $this->extend('commanfile/header'); ?>
<?= $this->section('content'); ?>


<!-- page title area end -->
<div class="main-content-inner">
    <div class="row">
        <!-- table primary start -->
        <div class="col-lg-12 mt-5">
            <div class="card">
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-center">
                        <button type="button" class="btn btn-warning btn-md mt-3 mb-3" data-toggle="modal" data-target="#userModal"> <i class="fa fa-user-plus"></i> Add User</button>
                    </div>

                    <div class="single-table">
                        <div class="table-responsive">
                            <table class="table text-center" id="usersTable">
                                <thead class="text-uppercase bg-primary">
                                    <tr class="text-white">
                                        <th scope="col">ID</th>
                                        <th scope="col">Name</th>
                                        <th scope="col">Email / Username</th>
                                        <th scope="col">Role</th>
                                        <th scope="col">Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <th scope="row">1</th>
                                        <td>Mark</td>
                                        <td>Mark@Demo.com</td>
                                        <td>Admin</td>
                                        <td><i class="ti-trash delete-icon"></i> | <i data-toggle="modal" data-target="#edituserModal" class="ti-pencil"></i></td>
                                    </tr>
                                    <tr>
                                        <th scope="row">2</th>
                                        <td>Mark</td>
                                        <td>Mark@Demo.com</td>
                                        <td>Dispatcher</td>
                                        <td><i class="ti-trash delete-icon"></i> | <i data-toggle="modal" data-target="#edituserModal" class="ti-pencil"></i></td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>


<?= $this->endSection(); ?>