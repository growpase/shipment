<?= $this->extend('commanfile/header'); ?>
<?= $this->section('content'); ?>

<!-- page title area end -->
<div class="main-content-inner">
    <div class="row">
        <!-- table primary start -->
        <div class="col-lg-12 mt-2">
            <div class="card">
                <div class="card-body">
                    <!-- <div class="d-flex justify-content-between align-items-center">
                        <button type="button" class="btn btn-success btn-md mt-3 mb-3" data-toggle="modal" data-target="#jobsheetModal"> <i class="fa fa-upload"></i> Upload Sheet</button>
                    </div> -->
                    <div class="row mb-2">
                        <!-- <div class="col-md-9">
                            <h5>Job Title : BABAHAR VILLA</h5>
                        </div> -->
                        <div class="col-md-3">
                            <button type="button" class="btn btn-success btn-md text-white" data-toggle="modal" data-target="#createjobsheetModal"> <i class="fa fa-plus mr-1"></i> Create Job</button>
                        </div>
                    </div>
                    <hr>

                    <div class="single-table" style="overflow-x: auto; max-width: 100%;">
                        <div class="table-responsive">
                            <table class="table table-bordered">
                                <thead class="text-uppercase bg-primary w-100">
                                    <tr class="text-white">
                                        <th >Job ID</th>
                                        <th >Date</th>
                                        <th >Job Name</th>
                                        <th >Job Type</th>
                                        <th >Client Name</th>
                                        <th >Manual Reff</th>
                                        <th >STAT</th>
                                        <th >Currency</th>
                                        <th >Project Cost</th>
                                        <th >Invoice Amount</th>
                                        <th >Balance Amount</th>
                                        <th >Dispatcher</th>
                                        <th >Handler</th>
                                        <th >Status</th>
                                        <th >Delivery Notes</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <th scope="row">1</th>
                                        <td>01 / 29 / 2024</td>
                                        <td><a href="<?= base_url() ?>jobsheet-detail">AKIRA BACK</a></td>
                                        <td>AUDIO VISUAL</td>
                                        <td>EASTERN HOSPITALITY COMPANY</td>
                                        <td>LG-AV-24/8064 R01</td>
                                        <td>T.I</td>
                                        <td>SAR</td>
                                        <td>20000</td>
                                        <td>15000</td>
                                        <td>5000</td>
                                        <td> Ghassan Nasif <a href="javascript:void(0)" data-toggle="modal" data-target="#assignuserModal"> <i class="fa fa-edit"></i> </a> </td>
                                        <td> Omar Mrayati <a href="javascript:void(0)" data-toggle="modal" data-target="#assignuserModal"> <i class="fa fa-edit"></i> </a> </td>
                                        <td> Approved <a href="javascript:void(0)" data-toggle="modal" data-target="#jobstatusModal"> <i class="fa fa-edit"></i> </a> </td>
                                        <td class="text-center"><a href="<?= base_url() ?>delivery-notes"><i class="ti-shopping-cart-full" title="Upload Delivery Notes"></i></a></td>

                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </div>
</div>

<div class="modal fade show" id="jobstatusModal" data-backdrop="static" tabindex="-1" role="dialog" aria-labelledby="staticBackdropLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal"><span>×</span></button>
                </div>
                <div class="modal-body">
                    <form action="">
                        <div class="row">
                            <div class="col-md-12">
                                <div class="form-group">
                                    <label for="">Update Status </label>
                                    <select name="" class="form-control" id="">
                                        <option value="">Select Option</option>
                                        <option value="1">Approved</option>
                                        <option value="2">To Be Approved</option>
                                        <option value="2">Rejected</option>
                                    </select>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    <button type="button" class="btn btn-danger">Save Changes</button>
                </div>
            </div>
        </div>
    </div>
</div>



<div class="modal fade show" id="createjobsheetModal" data-backdrop="static" tabindex="-1" role="dialog" aria-labelledby="staticBackdropLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Add Job</h5>
                    <button type="button" class="close" data-dismiss="modal"><span>×</span></button>
                </div>
                <div class="modal-body p-4">
                    <div class="row">
                        <div class="col-md-6 mb-2">
                            <label for="">Select Branch</label>
                            <select name="" id="" class="form-control">
                                <option value="">Select Branch</option>
                                <option value="">Branch 1</option>
                                <option value="">Branch 2</option>
                            </select>
                        </div>
                    </div>
                    <div class="row">
                        <div class="form-group col-md-6">
                            <label for="example-text-input" class="col-form-label">Job Name</label>
                            <input class="form-control" type="text" value="Carlos Rath">
                        </div>
                        <div class="form-group col-md-6">
                            <label for="example-text-input" class="col-form-label">Job Type</label>
                            <input class="form-control" type="text" value="Audiovisual">
                        </div>
                    </div>
                    <div class="row">
                        <div class="form-group col-md-12">
                            <label for="example-text-input" class="col-form-label">Client Name</label>
                            <input class="form-control" type="text" value="Eastern Company">
                        </div>
                    </div>
                    <div class="row">
                        <div class="form-group col-md-6">
                            <label for="example-text-input" class="col-form-label">Manual Reff.</label>
                            <input class="form-control" type="text" value="LG-AV-24/8061 R01">
                        </div>
                        <div class="form-group col-md-3">
                            <label for="example-text-input" class="col-form-label">Dispatcher</label>
                            <select class="custom-select">
                                <option>Select Option</option>
                                <option selected="selected"> Ghasan Nassif</option>
                                <option> Omar Mrayati</option>
                            </select>
                        </div>
                        <div class="form-group col-md-3">
                            <label class="col-form-label">Handler</label>
                            <select class="custom-select">
                                <option>Select Option</option>
                                <option selected="selected"> Omar Mrayati</option>
                                <option> Ghasan Nassif</option>
                            </select>
                        </div>
                    </div>
                    <div class="row">
                        <div class="form-group col-md-4">
                            <label for="example-text-input" class="col-form-label">STAT</label>
                            <input class="form-control" type="text" value="T.I">
                        </div>
                        <div class="form-group col-md-4">
                            <label for="example-text-input" class="col-form-label">Currency</label>
                            <input class="form-control" type="text" value="SAR">
                        </div>
                        <div class="form-group col-md-4">
                            <label class="col-form-label">Status</label>
                            <select class="custom-select">
                                <option>Select Option</option>
                                <option selected="selected"> Approved</option>
                                <option>To Be Approved</option>
                                <option>Rejected</option>
                            </select>
                        </div>
                    </div>
                    <div class="row">
                        <div class="form-group col-md-4">
                            <label for="example-text-input" class="col-form-label">Project Cost</label>
                            <input class="form-control" type="number" value="20000">
                        </div>
                        <div class="form-group col-md-4">
                            <label for="example-text-input" class="col-form-label">Total Invoice Issue</label>
                            <input class="form-control" type="number" value="10000">
                        </div>
                        <div class="form-group col-md-4">
                            <label for="example-text-input" class="col-form-label">Balance</label>
                            <input class="form-control" type="number" value="10000">
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    <button type="button" class="btn btn-danger">Save changes</button>
                </div>
            </div>
        </div>
    </div>
</div>

<?= $this->endSection();
