<?= $this->extend('commanfile/header'); ?>
<?= $this->section('content'); ?>

<!-- page title area end -->
<div class="main-content-inner">
    <div class="row">
        <!-- table primary start -->
        <div class="col-lg-12 mt-5">
            <div class="card">
                <div class="card-body">
                    <div class="row mb-2">
                        <div class="col-md-9">
                            <h5>Job ID : 360</h5>
                            <h5>Job Name : BABAHAR VILLA</h5>
                        </div>
                        <div class="col-md-3">
                            <button type="button" class="btn btn-warning btn-md text-white" data-toggle="modal" data-target="#adddeliverynotesModal"> <i class="fa fa-plus"></i> Add Delivery Note</button>
                        </div>
                    </div>
                    <hr>

                    <div class="single-table">
                        <div class="table-responsive">
                            <table class="table text-center" id="usersTable">
                                <thead class="text-uppercase bg-primary">
                                    <tr class="text-white">
                                        <th scope="col">ID</th>
                                        <th scope="col">Date</th>
                                        <th scope="col">Delivery Note</th>
                                        <th scope="col">Title</th>
                                        <th scope="col">Currency</th>
                                        <th scope="col">Net Amount</th>
                                        <th scope="col">Surveyor</th>

                                        <th scope="col">Issued Invoice</th>
                                        <th scope="col">Invoice Issue</th>
                                        <th scope="col">Signed</th>
                                        <th scope="col">Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td scope="row">1</td>
                                        <td>01 / 06 / 2024</td>
                                        <td>IO28</td>
                                        <td>Private Sector</td>
                                        <td>SAR</td>
                                        <td>14000</td>
                                        <td>Md. Munir Uddun</td>
                                        <td>Yes <a href="javascript:void(0)" data-toggle="modal" data-target="#jobstatusModal"><i class="fa fa-edit"></i> </a> </td>
                                        <td>No <a href="javascript:void(0)" data-toggle="modal" data-target="#jobstatusModal"><i class="fa fa-edit"></i> </a> </td>
                                        <td>Yes <a href="javascript:void(0)" data-toggle="modal" data-target="#signdnModal"><i class="fa fa-edit"></i> </a> </td>
                                        <td> <a href="<?= base_url() ?>deliverynote-detail"> <i class="fa fa-eye"></i> </a> | <i class="fa fa-trash-o delete-icon"></i></td>
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>


<div class="modal fade show" id="jobstatusModal" data-backdrop="static" tabindex="-1" role="dialog" aria-labelledby="staticBackdropLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal"><span>×</span></button>
                </div>
                <div class="modal-body">
                    <form action="">
                        <div class="row">
                            <div class="col-md-12">
                                <div class="form-group">
                                    <label for="">Invoice Issue </label>
                                    <select name="" class="form-control" id="">
                                        <option value="">Select Option</option>
                                        <option value="1">Yes</option>
                                        <option value="2">No</option>
                                    </select>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    <button type="button" class="btn btn-danger">Save Changes</button>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="modal fade show" id="adddeliverynotesModal" data-backdrop="static" tabindex="-1" role="dialog" aria-labelledby="staticBackdropLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Add Delivery Note</h5>
                    <button type="button" class="close" data-dismiss="modal"><span>×</span></button>
                </div>
                <div class="modal-body p-4">
                    <div class="row">
                        <div class="form-group col-md-6">
                            <label for="example-text-input" class="col-form-label">Delivery Note Id.</label>
                            <input class="form-control" type="text" value="IO9">
                        </div>
                        <div class="form-group col-md-6">
                            <label for="example-text-input" class="col-form-label">Date </label>
                            <input class="form-control" type="text" value="1/10/2024">
                        </div>
                    </div>

                    <div class="row">
                        <div class="form-group col-md-6">
                            <label for="example-text-input" class="col-form-label">Delivery Title</label>
                            <input class="form-control" type="text" value="Title">
                        </div>
                        <div class="form-group col-md-6">
                            <label for="example-text-input" class="col-form-label">Surveyor</label>
                            <input class="form-control" type="text" value="Md. Munir Uddun">
                        </div>
                    </div>

                    <div class="row">

                        <div class="form-group col-md-4">
                            <label for="example-text-input" class="col-form-label">City / Region</label>
                            <input class="form-control" type="text" value="RIYADH">
                        </div>

                        <div class="form-group col-md-4">
                            <label for="example-text-input" class="col-form-label">Currency</label>
                            <input class="form-control" type="text" value="SAR">
                        </div>
                        <div class="form-group col-md-4">
                            <label for="example-text-input" class="col-form-label">Net Total</label>
                            <input class="form-control" type="number" value="20000">
                        </div>

                    </div>

                    <div class="row">
                        <div class="form-group col-md-4">
                            <label class="col-form-label">Signed</label>
                            <select class="custom-select">
                                <option>Select Option</option>
                                <option selected="selected"> Yes</option>
                                <option>No</option>
                            </select>
                        </div>

                        <div class="form-group col-md-4">
                            <label class="col-form-label">Issue Invoice</label>
                            <select class="custom-select">
                                <option>Select Option</option>
                                <option selected="selected"> Yes</option>
                                <option>No</option>
                            </select>
                        </div>

                        <div class="form-group col-md-4">
                            <label class="col-form-label">Invoice Issued</label>
                            <select class="custom-select">
                                <option>Select Option</option>
                                <option selected="selected"> Yes</option>
                                <option>No</option>
                            </select>
                        </div>

                    </div>

                    <div class="row">
                        <div class="col-md-4">
                            <label for="">Status</label>
                            <select class="form-control" name="" id="">
                                <option value="">Select Status</option>
                                <option value="">DELIVERED</option>
                                <option value="">NOT DELIVERED</option>
                                <option value="">Other</option>
                            </select>
                        </div>

                        <div class="col-md-4">
                            <label for="">Remark</label>
                            <input type="text" value="IN RIYADH GODOWN" class="form-control">
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    <button type="button" class="btn btn-danger">Save changes</button>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="modal fade show" id="signdnModal" data-backdrop="static" tabindex="-1" role="dialog" aria-labelledby="staticBackdropLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal"><span>×</span></button>
                </div>
                <div class="modal-body">
                    <form action="">
                        <div class="row">
                            <div class="col-md-12">
                                <div class="form-group">
                                    <label for="">Signed Delivery Notes </label>
                                    <select name="" class="form-control" id="">
                                        <option value="">Select Option</option>
                                        <option value="1">Yes</option>
                                        <option value="2">No</option>
                                    </select>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    <button type="button" class="btn btn-danger">Save Changes</button>
                </div>
            </div>
        </div>
    </div>
</div>
<?= $this->endSection();
