<?= $this->extend('commanfile/header'); ?>
<?= $this->section('content'); ?>

<!-- page title area end -->
<div class="main-content-inner">
    <div class="row">
        <!-- table primary start -->
        <div class="col-lg-12 mt-5">
            <div class="card">
                <div class="card-body">
                    <div class="row mb-2">
                        <div class="col-md-3">
                            <div class="form-group">
                                <label for="">Job Id</label>
                                <select name="" id="" class="form-control">
                                    <option value="">Select Job Id</option>
                                    <option value="">360</option>
                                    <option value="">361</option>
                                </select>

                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="form-group">
                                <label for="">Job Name</label>
                                <select name="" id="" class="form-control">
                                    <option value="">Select Job Name</option>
                                    <option value="">AKIRA BACK</option>
                                </select>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <button type="button" class="btn btn-info btn-sm text-white mt-4"> <i class="fa fa-search"></i> Search Record</button>

                            <button type="button" class="btn btn-warning btn-sm text-white mt-4" data-toggle="modal" data-target="#jobsheetModal"> <i class="fa fa-upload"></i> Upload Delivery Note</button>
                        </div>

                    </div>
                    <hr>

                    <div class="single-table">
                        <div class="table-responsive">
                            <table class="table text-center" id="usersTable">
                                <thead class="text-uppercase bg-primary">
                                    <tr class="text-white">
                                        <th scope="col">ID</th>
                                        <th scope="col">Date</th>
                                        <th scope="col">Job Id</th>
                                        <th scope="col">Title</th>
                                        <th scope="col">Currency</th>
                                        <th scope="col">Net Amount</th>
                                        <th scope="col">Surveyor</th>

                                        <th scope="col">Issued Invoice</th>
                                        <th scope="col">Invoice Issue</th>
                                        <th scope="col">Signed</th>
                                        <th scope="col">Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td scope="row">IO28</td>
                                        <td>01 / 06 / 2024</td>
                                        <td>360</td>
                                        <td>Private Sector</td>
                                        <td>SAR</td>
                                        <td>14000</td>
                                        <td>Md. Munir Uddun</td>
                                        <td>Yes <a href="javascript:void(0)" data-toggle="modal" data-target="#jobstatusModal"><i class="fa fa-edit"></i> </a> </td>
                                        <td>No <a href="javascript:void(0)" data-toggle="modal" data-target="#jobstatusModal"><i class="fa fa-edit"></i> </a> </td>
                                        <td>Yes <a href="javascript:void(0)" data-toggle="modal" data-target="#signdnModal"><i class="fa fa-edit"></i> </a> </td>
                                        <td> <a href="<?= base_url() ?>deliverynote-detail"> <i class="fa fa-eye"></i> </a> | <i class="fa fa-trash-o delete-icon"></i></td>
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="modal fade show" id="jobstatusModal" data-backdrop="static" tabindex="-1" role="dialog" aria-labelledby="staticBackdropLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal"><span>×</span></button>
                </div>
                <div class="modal-body">
                    <form action="">
                        <div class="row">
                            <div class="col-md-12">
                                <div class="form-group">
                                    <label for="">Invoice Issue </label>
                                    <select name="" class="form-control" id="">
                                        <option value="">Select Option</option>
                                        <option value="1">Yes</option>
                                        <option value="2">No</option>
                                    </select>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    <button type="button" class="btn btn-danger">Save Changes</button>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="modal fade show" id="editdeliverynotesModal" data-backdrop="static" tabindex="-1" role="dialog" aria-labelledby="staticBackdropLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Edit User</h5>
                    <button type="button" class="close" data-dismiss="modal"><span>×</span></button>
                </div>
                <div class="modal-body">
                    <form action="">
                        <div class="row">
                            <div class="col-md-12">
                                <div class="form-group">
                                    <label for="">Delivery Note</label>
                                    <input type="text" class="form-control" value="IO9" placeholder="Enter Name">
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="">Date</label>
                                    <input type="text" class="form-control" value="01-06-2024" placeholder="Enter email / Username">
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="">Surveyor </label>
                                    <input type="text" class="form-control" value="Md. Munir Uddun" placeholder="Enter Contact Number">
                                </div>
                            </div>

                            <div class="col-md-12">
                                <div class="form-group">
                                    <label for="">Job </label>
                                    <input type="text" value="Akira Back" class="form-control" placeholder="Set a Password">
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    <button type="button" class="btn btn-danger">Save changes</button>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="modal fade show" id="signdnModal" data-backdrop="static" tabindex="-1" role="dialog" aria-labelledby="staticBackdropLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal"><span>×</span></button>
                </div>
                <div class="modal-body">
                    <form action="">
                        <div class="row">
                            <div class="col-md-12">
                                <div class="form-group">
                                    <label for="">Signed Delivery Notes </label>
                                    <select name="" class="form-control" id="">
                                        <option value="">Select Option</option>
                                        <option value="1">Yes</option>
                                        <option value="2">No</option>
                                    </select>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    <button type="button" class="btn btn-danger">Save Changes</button>
                </div>
            </div>
        </div>
    </div>
</div>
<?= $this->endSection();
