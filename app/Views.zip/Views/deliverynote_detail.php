<?= $this->extend('commanfile/header'); ?>
<?= $this->section('content'); ?>

<!-- page title area end -->
<div class="main-content-inner">
    <div class="row">
        <div class="col-12 mt-5">
            <div class="card">

                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-center">
                        <button type="button" class="btn btn-warning btn-sm" data-toggle="modal" data-target="#jobsheetModal"> <i class="fa fa-edit"> </i> Edit</button>
                    </div>
                    <hr>
                    <div class="row">
                        <div class="form-group col-md-6">
                            <label for="example-text-input" class="col-form-label">Delivery Note Id.</label>
                            <input class="form-control" type="text" value="IO9">
                        </div>
                        <div class="form-group col-md-6">
                            <label for="example-text-input" class="col-form-label">Date </label>
                            <input class="form-control" type="text" value="1/10/2024">
                        </div>
                    </div>

                    <div class="row">
                        <div class="form-group col-md-6">
                            <label for="example-text-input" class="col-form-label">Delivery Title</label>
                            <input class="form-control" type="text" value="Title">
                        </div>
                        <div class="form-group col-md-6">
                            <label for="example-text-input" class="col-form-label">Surveyor</label>
                            <input class="form-control" type="text" value="Md. Munir Uddun">
                        </div>
                    </div>

                    <div class="row">
                        <div class="form-group col-md-4">
                            <label for="example-text-input" class="col-form-label">City / Region</label>
                            <input class="form-control" type="text" value="RIYADH">
                        </div>
                        <div class="form-group col-md-4">
                            <label for="example-text-input" class="col-form-label">Currency</label>
                            <input class="form-control" type="text" value="SAR">
                        </div>
                        <div class="form-group col-md-4">
                            <label for="example-text-input" class="col-form-label">Estimated Value</label>
                            <input class="form-control" type="number" value="20000">
                        </div>

                    </div>

                    <div class="row">
                        <div class="form-group col-md-4">
                            <label class="col-form-label">Signed</label>
                            <select class="custom-select">
                                <option>Select Option</option>
                                <option selected="selected"> Yes</option>
                                <option>No</option>
                            </select>
                        </div>

                        <div class="form-group col-md-4">
                            <label class="col-form-label">Issue Invoice</label>
                            <select class="custom-select">
                                <option>Select Option</option>
                                <option selected="selected"> Yes</option>
                                <option>No</option>
                            </select>
                        </div>

                        <div class="form-group col-md-4">
                            <label class="col-form-label">Invoice Issued</label>
                            <select class="custom-select">
                                <option>Select Option</option>
                                <option selected="selected"> Yes</option>
                                <option>No</option>
                            </select>
                        </div>

                    </div>

                    <div class="row">
                        <div class="col-md-4">
                            <label for="">Status</label>
                            <select class="form-control" name="" id="">
                                <option value="">Select Status</option>
                                <option value="">DELIVERED</option>
                                <option value="">NOT DELIVERED</option>
                                <option value="">Other</option>
                            </select>
                        </div>

                        <div class="col-md-4">
                            <label for="">Remark</label>
                            <input type="text" value="IN RIYADH GODOWN" class="form-control">
                        </div>
                    </div>
                    <hr>
                    <div class="row">
                        <div class="form-group col-md-4">
                            <button type="button" class="btn btn-warning mb-3">Save Changes</button>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>
</div>



<?= $this->endSection();
