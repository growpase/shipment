<?= $this->extend('commanfile/header'); ?>
<?= $this->section('content'); ?>

<!-- page title area end -->
<div class="main-content-inner">
    <div class="login-area">
        <div class="container">
            <div class="login-box">
                <form method="POST">
                    <div class="login-form-head">
                        <h4>Import Here</h4>
                    </div>

                    <div class="login-form-body">
                        <div class="form-gp">
                            <!-- <label for="">Select Branch</label> -->
                            <select name="" id="" class="form-control">
                                <option value="">Select Branch</option>
                                <option value="">Branch 1</option>
                                <option value="">Branch 2</option>
                            </select>
                        </div>
                        <div class="form-gp">
                            <!-- <label for="exampleInputEmail1">Username</label> -->
                            <input type="file" id="exampleInputEmail1">
                            <i class="ti-file"></i>
                            <div class="text-danger"></div>
                        </div>
                        <div class="submit-btn-area">
                            <a id="form_submit" href="<?= base_url() ?>dashboard" type="submit">Upload File <i class="ti-upload"></i></a>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<?= $this->endSection();
