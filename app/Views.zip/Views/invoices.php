<?= $this->extend('commanfile/header'); ?>
<?= $this->section('content'); ?>

<!-- page title area end -->
<div class="main-content-inner">
    <div class="row">
        <!-- table primary start -->
        <div class="col-lg-12 mt-5">
            <div class="card">
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-center">
                        <button type="button" class="btn btn-danger btn-md mt-3 mb-3" data-toggle="modal" data-target="#jobsheetModal"> <i class="fa fa-upload"></i> Upload Invoice Sheet</button>
                    </div>

                    <div class="single-table">
                        <div class="table-responsive">
                            <table class="table text-center" id="usersTable">
                                <thead class="text-uppercase bg-primary">
                                    <tr class="text-white">
                                        <th scope="col">ID</th>
                                        <th scope="col">Invoice No</th>
                                        <th scope="col">Client </th>
                                        <th scope="col">Job </th>
                                        <th scope="col">Handler </th>
                                        <th scope="col">Date</th>
                                        <th scope="col">Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <th scope="row">1</th>
                                        <td>119</td>
                                        <td>Saudi Structure Contracting Co.</td>
                                        <td>AKIRA BACK</td>
                                        <td>Omar Mrayati</td>
                                        <td>09 / 07 / 2018</td>
                                        <!-- <td><button class="btn btn-sm btn-success" data-toggle="modal" data-target="#jobstatusModal"><i class="fa fa-edit"></i> Status</button> </td> -->
                                        <td><i data-toggle="modal" data-target="#editdeliverynotesModal" class="ti-pencil"></i> | <i class="fa fa-trash-o delete-icon"></i></td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?= $this->endSection();
