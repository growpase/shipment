<?= $this->extend('commanfile/header'); ?>
<?= $this->section('content'); ?>

<!-- page title area end -->
<div class="main-content-inner">
    <div class="row">
        <div class="col-12 mt-5">
            <div class="card">

                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-center">
                        <button type="button" class="btn btn-success btn-sm" data-toggle="modal" data-target="#jobsheetModal"> <i class="fa fa-edit"></i>Edit</button>
                    </div>
                    <hr>

                    <div class="row">
                        <div class="col-md-6 mb-2">
                            <label for="">Select Branch</label>
                            <select name="" id="" class="form-control">
                                <option value="">Branch 1</option>
                                <option value="">Branch 2</option>
                            </select>
                        </div>
                    </div>
                    <div class="row">
                        <div class="form-group col-md-6">
                            <label for="example-text-input" class="col-form-label">Job Name</label>
                            <input class="form-control" type="text" value="Carlos Rath">
                        </div>

                        <div class="form-group col-md-6">
                            <label for="example-text-input" class="col-form-label">Job Type</label>
                            <input class="form-control" type="text" value="Audiovisual">
                        </div>
                    </div>

                    <div class="row">
                        <div class="form-group col-md-12">
                            <label for="example-text-input" class="col-form-label">Client Name</label>
                            <input class="form-control" type="text" value="Eastern Company">
                        </div>
                    </div>
                    <div class="row">
                        <div class="form-group col-md-6">
                            <label for="example-text-input" class="col-form-label">Manual Reff.</label>
                            <input class="form-control" type="text" value="LG-AV-24/8061 R01">
                        </div>
                        <div class="form-group col-md-3">
                            <label for="example-text-input" class="col-form-label">Dispatcher</label>
                            <select class="custom-select">
                                <option>Select Option</option>
                                <option selected="selected"> Ghasan Nassif</option>
                                <option> Omar Mrayati</option>
                            </select>
                        </div>
                        <div class="form-group col-md-3">
                            <label class="col-form-label">Handler</label>
                            <select class="custom-select">
                                <option>Select Option</option>
                                <option selected="selected"> Omar Mrayati</option>
                                <option> Ghasan Nassif</option>
                            </select>
                        </div>
                    </div>

                    <div class="row">
                        <div class="form-group col-md-4">
                            <label for="example-text-input" class="col-form-label">STAT</label>
                            <input class="form-control" type="text" value="T.I">
                        </div>
                        <div class="form-group col-md-4">
                            <label for="example-text-input" class="col-form-label">Currency</label>
                            <input class="form-control" type="text" value="SAR">
                        </div>
                        <div class="form-group col-md-4">
                            <label class="col-form-label">Status</label>
                            <select class="custom-select">
                                <option>Select Option</option>
                                <option selected="selected"> Approved</option>
                                <option>To Be Approved</option>
                                <option>Rejected</option>
                            </select>
                        </div>
                    </div>

                    <div class="row">
                        <div class="form-group col-md-4">
                            <label for="example-text-input" class="col-form-label">Project Cost</label>
                            <input class="form-control" type="number" value="20000">
                        </div>
                        <div class="form-group col-md-4">
                            <label for="example-text-input" class="col-form-label">Total Invoice Issue</label>
                            <input class="form-control" type="number" value="10000">
                        </div>
                        <div class="form-group col-md-4">
                            <label for="example-text-input" class="col-form-label">Balance</label>
                            <input class="form-control" type="number" value="10000">
                        </div>
                    </div>
                    <hr>
                    <div class="row">
                        <div class="form-group col-md-4">
                            <button type="button" class="btn btn-success mb-3">Save Changes</button>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>
</div>



<?= $this->endSection();
