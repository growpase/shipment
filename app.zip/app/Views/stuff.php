<li><a href="<?= base_url() ?>dashboard"><i class="ti-map-alt"></i> <span>Dashboard</span></a></li>
<li><a href="<?= base_url() ?>user"><i class="ti-map-alt"></i> <span>User</span></a></li>
<li><a href="<?= base_url() ?>job"><i class="ti-map-alt"></i> <span>Jobs</span></a></li>
<li><a href="<?= base_url() ?>DeliveryIssues"><i class="ti-map-alt"></i> <span>Delivery Issues</span></a></li>